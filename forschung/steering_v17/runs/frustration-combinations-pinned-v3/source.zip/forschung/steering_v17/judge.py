"""Optional blind local/Groq semantic ratings, separately stored from diagnostics."""

from __future__ import annotations
import hashlib
import argparse
import json
from pathlib import Path

import httpx

from config.prompts import STEERING_V17_JUDGE_PROMPT
from forschung.steering_v17.evaluate import response_text

RATING_KEYS = (
    "happiness",
    "trust",
    "energy",
    "curiosity",
    "motivation",
    "frustration",
    "sadness",
    "affection",
    "anxiety",
    "calm",
    "directness",
    "hostility",
    "sarcasm",
    "insult",
    "boundary_setting",
    "content_preservation",
    "naturalness",
)


def rate(client, prompt: str, answer: str, *, endpoint: str, model: str, max_tokens: int = 512) -> dict:
    request = {
        "model": model,
        "messages": [
            {"role": "system", "content": STEERING_V17_JUDGE_PROMPT},
            {
                "role": "user",
                "content": json.dumps(
                    {"prompt": prompt, "answer": answer}, ensure_ascii=False
                ),
            },
        ],
        "temperature": 0,
        "seed": 1042,
        "max_tokens": max_tokens,
        "chat_template_kwargs": {"enable_thinking": False},
        "steering": {"enabled": False, "mode": "off", "vectors": [], "sequences": []},
    }
    response = client.post(endpoint.rstrip("/") + "/v1/chat/completions", json=request)
    response.raise_for_status()
    payload = response.json()
    result = {"request": request, "response": payload, "method": "blind_automated_local",
              "independent_human_rating": False}
    try:
        text = payload["choices"][0]["message"]["content"]
        first, last = text.find("{"), text.rfind("}")
        if first < 0 or last < first:
            raise ValueError("Judge did not return JSON")
        rating = json.loads(text[first:last+1])
        if any(type(rating.get(key)) is not int or not 0 <= rating[key] <= 4 for key in RATING_KEYS):
            raise ValueError("Judge returned invalid or missing rating dimensions")
        result["rating"] = {key: rating[key] for key in RATING_KEYS}
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        result["error"] = str(exc)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--endpoint", default="http://127.0.0.1:8000")
    parser.add_argument("--model", default="Qwen/Qwen3.5-4B")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--reference-ratings", type=Path)
    args = parser.parse_args()
    rows = [
        json.loads(line)
        for line in (args.run / "generations.jsonl").read_text().splitlines()
    ]
    path = args.run / "blind_ratings.jsonl"
    prior = (
        [json.loads(line) for line in path.read_text().splitlines()]
        if path.exists()
        else []
    )
    done = {row["response_id"] for row in prior if "error" not in row}
    cache = {item["input_hash"]: item for item in prior if "input_hash" in item and ("rating" in item or ("error" in item and "response" in item))}
    if args.reference_ratings:
        reference_hash = hashlib.sha256(args.reference_ratings.read_bytes()).hexdigest()
        for item in map(json.loads, args.reference_ratings.read_text().splitlines()):
            if "rating" in item and "error" not in item and "input_hash" in item:
                cache.setdefault(item["input_hash"], {**item, "reference_sha256": reference_hash})
    count = 0
    with httpx.Client(timeout=120) as client, path.open("a") as log:
        for row in rows:
            if "error" in row:
                continue
            response_id = row["response"].get("id")
            if not response_id or response_id in done:
                continue
            input_hash = hashlib.sha256(json.dumps([row["prompt"], response_text(row), args.model, STEERING_V17_JUDGE_PROMPT]).encode()).hexdigest()
            rated = {"response_id": response_id, "input_hash": input_hash}
            if input_hash in cache:
                source = cache[input_hash]
                rated.update({**{key: source[key] for key in ("rating", "error") if key in source}, "method": "blind_automated_local_cached",
                              "independent_human_rating": False, "cached_from_response_id": source["response_id"]})
                if source.get("reference_sha256"):
                    rated["reference_ratings_sha256"] = source["reference_sha256"]
                    rated["reference_ratings_path"] = str(args.reference_ratings)
                log.write(json.dumps(rated, ensure_ascii=False) + "\n")
                log.flush()
                done.add(response_id)
                continue
            try:
                rated.update(
                    rate(
                        client,
                        row["prompt"],
                        response_text(row),
                        endpoint=args.endpoint,
                        model=args.model,
                    )
                )
            except (httpx.HTTPError, ValueError, KeyError) as exc:
                rated["error"] = str(exc)
            log.write(json.dumps(rated, ensure_ascii=False) + "\n")
            log.flush()
            if "rating" in rated or ("error" in rated and "response" in rated):
                cache[input_hash] = rated
            if "rating" in rated:
                done.add(response_id)
            count += 1
            print(response_id, "error" if "error" in rated else "rated", flush=True)
            if args.limit and count >= args.limit:
                break


if __name__ == "__main__":
    main()
