"""Rank only fully rated sweep configurations, using blind perceived emotion."""
import argparse
import hashlib
import json
from pathlib import Path
from statistics import mean

def rank(run, emotion="frustration"):
    generation_path, rating_path = run / "generations.jsonl", run / "blind_ratings.jsonl"
    rows = [json.loads(line) for line in generation_path.read_text().splitlines()]
    ratings = {row["response_id"]: row for row in map(json.loads, rating_path.read_text().splitlines())}
    groups = {}
    for row in rows:
        groups.setdefault((tuple(row["layers"]), row["strength"]), {})[row["case_id"]] = row
    ranking, excluded = [], []
    for (layers, strength), cases in groups.items():
        pairs = [(row, ratings.get(row.get("response", {}).get("id"), {})) for row in cases.values()]
        if len(pairs) != 8 or any("rating" not in rating or "error" in rating for _, rating in pairs):
            excluded.append({"layers": list(layers), "strength": strength, "reason": "missing_or_invalid_blind_rating"})
            continue
        effect = mean(rating["rating"][emotion] / 4 for row, rating in pairs if row["category"] != "neutral_control")
        content = mean(rating["rating"]["content_preservation"] / 4 for _, rating in pairs)
        naturalness = mean(rating["rating"]["naturalness"] / 4 for _, rating in pairs)
        score = effect - .25 * (1-content) - .25 * (1-naturalness)
        ranking.append({"layers": list(layers), "strength": strength, "cases": 8,
                        "semantic_selection_score": score, "emotion_expression": effect,
                        "content_preservation": content, "naturalness": naturalness})
    ranking.sort(key=lambda row: row["semantic_selection_score"], reverse=True)
    result = {"ranking_method": "blind_local_emotion_minus_content_and_naturalness_penalty",
              "formula": "mean(emotion/4) on emotional cases - 0.25*(1-mean(content/4)) - 0.25*(1-mean(naturalness/4))",
              "production_acceptance": False, "independent_human_rating": False,
              "emotion": emotion, "ranking": ranking, "excluded": excluded,
              "generations_sha256": hashlib.sha256(generation_path.read_bytes()).hexdigest(),
              "ratings_sha256": hashlib.sha256(rating_path.read_bytes()).hexdigest()}
    (run / "semantic_layer_metrics.json").write_text(json.dumps(result, indent=2)+'\n')
    return result

if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',type=Path,required=True)
    parser.add_argument('--emotion',default='frustration')
    args=parser.parse_args()
    result=rank(args.run,args.emotion)
    print(json.dumps({"top":result['ranking'][:8],"excluded":len(result['excluded'])},indent=2))
    if len(result['ranking']) < 8:
        raise SystemExit('Fewer than eight completely rated layer configurations')
