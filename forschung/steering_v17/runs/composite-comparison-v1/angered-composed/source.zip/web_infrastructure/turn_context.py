"""Turn input normalization shared by sync and streaming adapters."""

from __future__ import annotations

import re

from typing import Any, Dict, List, Optional

from web_infrastructure.contracts import StatusCallback, TurnContext
from config.session_settings import SessionRuntimeSettings


# Degenerierte Assistenten-Turns (Fallbacks, Fragmente, Prompt-Leaks) duerfen
# nie in die History des naechsten Turns: Das Modell imitiert sie sonst und
# die Generierung spiralt in 2-Token-Kollaps ("CHAPPiE schweigt...", "user...").
# User-Turns bleiben immer erhalten, damit keine Konversation verloren geht.
DEGENERATE_ASSISTANT_MARKERS = (
    "CHAPPiE schweigt",
    "CHAPPiE hat nachgedacht, schweigt aber",
    "CHAPPiE hat nicht darueber nachgedacht",
)
DEGENERATE_ASSISTANT_MIN_CHARS = 20


def sanitize_history(history: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    """Entfernt degenerierte Assistenten-Turns aus der Verlaufshistory."""
    cleaned: List[Dict[str, Any]] = []
    for msg in history or []:
        if not isinstance(msg, dict):
            continue
        role = str(msg.get("role", ""))
        content = msg.get("content", "")
        text = content if isinstance(content, str) else str(content or "")
        if role == "assistant":
            stripped = text.strip()
            if len(stripped) < DEGENERATE_ASSISTANT_MIN_CHARS:
                continue
            lowered = stripped.lower()
            if any(marker.lower() in lowered for marker in DEGENERATE_ASSISTANT_MARKERS):
                continue
            if stripped.rstrip(".!?,;:").lower() in {"user", "assistant", "system"}:
                continue
        cleaned.append(msg)
    return cleaned



def is_self_contained_math_query(text: str) -> bool:
    """Detect closed arithmetic that must not be influenced by autobiographical RAG."""
    normalized = str(text or "").lower().replace("×", "*").replace("÷", "/")
    number_words = (
        "null|eins|ein|eine|zwei|drei|vier|fuenf|fünf|sechs|sieben|acht|neun|"
        "zehn|elf|zwoelf|zwölf|dreizehn|vierzehn|fuenfzehn|fünfzehn|sechzehn|"
        "siebzehn|achtzehn|neunzehn|zwanzig"
    )
    operand = rf"(?:-?\d+(?:[.,]\d+)?|(?:{number_words}))"
    operator = r"(?:\+|-|\*|/|x|plus|minus|mal|geteilt\s+durch|dividiert\s+durch)"
    return bool(re.search(rf"\b{operand}\s*{operator}\s*{operand}\b", normalized))

def is_transient_problem_statement(text: str) -> bool:
    """Detect a short operational/frustration report without a recall request.

    These turns should still update emotion and life state, but old semantic
    conversation summaries about crashes or system failure are not useful
    evidence for the immediate response.  Explicit questions about a past
    problem do not match and continue to use the normal memory path.
    """
    normalized = str(text or "").casefold()
    return bool(re.search(
        r"(?:\bfunktioniert\s+(?:nicht|nix|nichts)\b|\bgeht\s+nicht\b|"
        r"\balles\s+(?:ist\s+)?kaputt\b|\bkomplett\s+kaputt\b|"
        r"\b(?:total|alles)\s+falsch\b)",
        normalized,
    ))

def context_allows_long_term_memory(requirements: Dict[str, bool] | None) -> bool:
    """Make the Step-1 context contract authoritative for semantic retrieval."""
    return bool((requirements or {}).get("need_long_term_memory", True))

def is_isolated_request(requirements: Dict[str, bool] | None) -> bool:
    keys = (
        "need_soul_context",
        "need_user_context",
        "need_preferences",
        "need_short_term_memory",
        "need_long_term_memory",
    )
    values = requirements or {}
    return not any(bool(values.get(key, True)) for key in keys)

def build_turn_context(
    user_input: str,
    history: Optional[List[Dict[str, Any]]],
    *,
    debug_mode: bool = False,
    status_callback: Optional[StatusCallback] = None,
    temporal_context: Optional[Dict[str, Any]] = None,
    session_id: Optional[str] = None,
    runtime_settings: Optional[SessionRuntimeSettings] = None,
) -> TurnContext:
    """Create an isolated request object without changing user text semantics."""

    snapshot = runtime_settings or SessionRuntimeSettings.from_mapping()
    return TurnContext(
        user_input=str(user_input),
        history=sanitize_history(history) if snapshot.memory_enabled else [],
        debug_mode=bool(debug_mode),
        status_callback=status_callback,
        temporal_context=dict(temporal_context) if temporal_context is not None else None,
        session_id=session_id,
        runtime_settings=snapshot,
    )
