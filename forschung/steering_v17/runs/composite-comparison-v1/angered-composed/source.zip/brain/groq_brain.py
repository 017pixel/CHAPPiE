"""
CHAPiE - Groq Brain
====================
LLM-Backend für Groq Cloud API.

Groq bietet:
- Extrem schnelle Inferenz (LPU-beschleunigt)
- Zugang zu Llama, Qwen, GPT-OSS Modellen
- OpenAI-kompatible API
- Native Function/Tool Calling

Benötigt: Groq API Key (https://console.groq.com/keys)
"""

import re
import time
from typing import Generator, Optional, List, Dict, Any
from openai import OpenAI

from .base_brain import BaseBrain, Message, GenerationConfig
from .groq_limits import get_groq_limiter
from config.config import settings


class GroqBrain(BaseBrain):
    """
    LLM-Backend für Groq Cloud API.

    Groq nutzt eine OpenAI-kompatible API mit eigenem Endpoint.
    Unterstützt Streaming für flüssige Token-Ausgabe.
    """

    BASE_URL = "https://api.groq.com/openai/v1"
    MAX_RATE_LIMIT_RETRIES = 4
    MAX_RATE_LIMIT_DELAY_SECONDS = 1800.0

    def __init__(self, model: Optional[str] = None, api_key: Optional[str] = None):
        self.api_key = api_key or getattr(settings, 'groq_api_key', '')
        model_name = model or getattr(settings, 'groq_model', 'openai/gpt-oss-120b')
        super().__init__(model_name)

        if self._is_missing_key(self.api_key):
            print("WARNUNG: Groq Brain - Kein API-Key konfiguriert!")
            print("   Trage deinen Key in CHAPPIE_CONFIG.json ein")
            self._is_initialized = False
            return

        try:
            self.client = OpenAI(
                base_url=self.BASE_URL,
                api_key=self.api_key,
                timeout=30.0,
            )
            self._is_initialized = True

            print(f"Groq Brain initialisiert")
            print(f"   Cloud API verbunden ({self.BASE_URL})")
            print(f"   Modell: {self.model}")
        except Exception as e:
            print(f"FEHLER bei Groq-Initialisierung: {e}")
            self._is_initialized = False

    def generate(
        self,
        messages: list[Message],
        config: Optional[GenerationConfig] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
    ) -> Generator[str, None, None] | str:
        if not self._is_initialized:
            error_msg = "FEHLER: Groq nicht initialisiert - API-Key fehlt!"
            if config and config.stream:
                def error_gen():
                    yield error_msg
                return error_gen()
            return error_msg

        if config is None:
            config = GenerationConfig(
                max_tokens=settings.max_tokens,
                temperature=settings.temperature,
                stream=settings.stream
            )

        openai_messages = [
            {"role": msg.role, "content": msg.content}
            for msg in messages
        ]

        if config.stream:
            return self._stream_generate(openai_messages, config, tools=tools, tool_choice=tool_choice)
        else:
            return self._sync_generate(openai_messages, config, tools=tools, tool_choice=tool_choice)

    @staticmethod
    def _is_missing_key(api_key: str) -> bool:
        normalized = (api_key or "").strip()
        return not normalized or normalized.startswith("DEIN_") or not normalized.startswith("gsk_")

    def _completion_token_budget(self, config: GenerationConfig) -> int:
        requested = int(config.max_tokens or 0)
        if self.model.startswith("openai/gpt-oss-") and not settings.chain_of_thought:
            # GPT-OSS cannot disable reasoning on Groq. Its reasoning and visible
            # answer share max_completion_tokens, so 450 total tokens can
            # leave an empty or truncated answer even with the lowest effort.
            return max(1024, requested)
        return requested

    def _estimate_request_tokens(self, messages: list[dict], config: GenerationConfig) -> int:
        text = "\n".join(str(message.get("content", "")) for message in messages)
        return get_groq_limiter().estimate_tokens(text) + self._completion_token_budget(config)

    def _apply_model_specific_options(self, kwargs: dict, config: GenerationConfig) -> None:
        if not self.model.startswith("openai/gpt-oss-"):
            kwargs["max_tokens"] = config.max_tokens
            return
        kwargs["max_completion_tokens"] = self._completion_token_budget(config)
        if settings.chain_of_thought:
            kwargs["reasoning_effort"] = "medium"
        else:
            # Groq supports low/medium/high for GPT-OSS, but no "none". The
            # model-specific API excludes reasoning via include_reasoning=false;
            # low is the closest possible match to thinking off.
            kwargs["reasoning_effort"] = "low"
            kwargs["extra_body"] = {"include_reasoning": False}

    def _claim_quota(self, messages: list[dict], config: GenerationConfig) -> Optional[str]:
        allowed, reason = get_groq_limiter().can_start(self._estimate_request_tokens(messages, config))
        return None if allowed else reason

    @staticmethod
    def _rate_limit_retry_delay(error: Exception, attempt: int) -> Optional[float]:
        text = str(error)
        status_code = getattr(error, "status_code", None)
        if status_code != 429 and "Error code: 429" not in text and "rate limit" not in text.lower():
            return None
        response = getattr(error, "response", None)
        headers = getattr(response, "headers", {}) or {}
        retry_after = headers.get("retry-after") if hasattr(headers, "get") else None
        if retry_after:
            try:
                return min(GroqBrain.MAX_RATE_LIMIT_DELAY_SECONDS, max(0.25, float(retry_after)))
            except (TypeError, ValueError):
                pass
        compound = re.search(
            r"try again in\s+(?:(\d+(?:\.\d+)?)\s*m\s*)?([0-9.]+)\s*s",
            text,
            re.IGNORECASE,
        )
        if compound:
            minutes = float(compound.group(1) or 0)
            seconds = float(compound.group(2))
            return min(
                GroqBrain.MAX_RATE_LIMIT_DELAY_SECONDS,
                max(0.25, minutes * 60 + seconds),
            )
        match = re.search(r"try again in\s+([0-9.]+)\s*(ms|s)", text, re.IGNORECASE)
        if match:
            delay = float(match.group(1))
            if match.group(2).lower() == "ms":
                delay /= 1000.0
            return min(GroqBrain.MAX_RATE_LIMIT_DELAY_SECONDS, max(0.25, delay))
        return min(GroqBrain.MAX_RATE_LIMIT_DELAY_SECONDS, float(2 ** attempt))

    def _stream_generate(
        self,
        messages: list[dict],
        config: GenerationConfig,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
    ) -> Generator[str, None, None]:
        try:
            quota_error = self._claim_quota(messages, config)
            if quota_error:
                yield f"\nGroq Fehler: Rate-Limit erreicht ({quota_error})"
                return

            kwargs = {
                "model": self.model,
                "messages": messages,
                "temperature": config.temperature,
                "stream": True,
            }
            if config.seed is not None:
                kwargs["seed"] = int(config.seed)
            self._apply_model_specific_options(kwargs, config)
            if settings.top_p is not None:
                kwargs["top_p"] = float(settings.top_p)
            if tools:
                kwargs["tools"] = tools
                kwargs["tool_choice"] = tool_choice or "auto"

            attempt = 0
            while True:
                emitted = False
                try:
                    stream = self.client.chat.completions.create(**kwargs)
                    for chunk in stream:
                        if chunk.choices and chunk.choices[0].delta.content:
                            emitted = True
                            yield chunk.choices[0].delta.content
                    return
                except Exception as error:
                    delay = self._rate_limit_retry_delay(error, attempt)
                    if emitted or delay is None or attempt >= self.MAX_RATE_LIMIT_RETRIES:
                        raise
                    attempt += 1
                    print(f"Groq Rate-Limit: Retry {attempt}/{self.MAX_RATE_LIMIT_RETRIES} in {delay:.2f}s")
                    time.sleep(delay)

        except Exception as e:
            yield f"\nGroq Fehler: {str(e)}"

    def _sync_generate(
        self,
        messages: list[dict],
        config: GenerationConfig,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
    ) -> str:
        try:
            quota_error = self._claim_quota(messages, config)
            if quota_error:
                return f"Groq Fehler: Rate-Limit erreicht ({quota_error})"

            kwargs = {
                "model": self.model,
                "messages": messages,
                "temperature": config.temperature,
                "stream": False,
            }
            if config.seed is not None:
                kwargs["seed"] = int(config.seed)
            self._apply_model_specific_options(kwargs, config)
            if settings.top_p is not None:
                kwargs["top_p"] = float(settings.top_p)
            if tools:
                kwargs["tools"] = tools
                kwargs["tool_choice"] = tool_choice or "auto"

            for attempt in range(self.MAX_RATE_LIMIT_RETRIES + 1):
                try:
                    response = self.client.chat.completions.create(**kwargs)
                    return response.choices[0].message.content
                except Exception as error:
                    delay = self._rate_limit_retry_delay(error, attempt)
                    if delay is None or attempt >= self.MAX_RATE_LIMIT_RETRIES:
                        raise
                    print(f"Groq Rate-Limit: Retry {attempt + 1}/{self.MAX_RATE_LIMIT_RETRIES} in {delay:.2f}s")
                    time.sleep(delay)

        except Exception as e:
            return f"Groq Fehler: {str(e)}"

    def generate_with_tools(
        self,
        messages: list[Message],
        config: Optional[GenerationConfig] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Sync-Generierung mit Tool-Support. Gibt kompletten Response zurueck.
        
        Returns: {"content": str, "tool_calls": list | None}
        """
        if not self._is_initialized:
            return {"content": "FEHLER: Groq nicht initialisiert", "tool_calls": None}

        if config is None:
            config = GenerationConfig(max_tokens=settings.max_tokens, temperature=settings.temperature, stream=False)

        openai_messages = [{"role": msg.role, "content": msg.content} for msg in messages]

        try:
            quota_error = self._claim_quota(openai_messages, config)
            if quota_error:
                return {"content": f"Groq Fehler: Rate-Limit erreicht ({quota_error})", "tool_calls": None}

            kwargs = {
                "model": self.model,
                "messages": openai_messages,
                "temperature": config.temperature,
                "stream": False,
            }
            self._apply_model_specific_options(kwargs, config)
            if settings.top_p is not None:
                kwargs["top_p"] = float(settings.top_p)
            if tools:
                kwargs["tools"] = tools
                kwargs["tool_choice"] = tool_choice or "auto"

            response = None
            for attempt in range(self.MAX_RATE_LIMIT_RETRIES + 1):
                try:
                    response = self.client.chat.completions.create(**kwargs)
                    break
                except Exception as error:
                    delay = self._rate_limit_retry_delay(error, attempt)
                    if delay is None or attempt >= self.MAX_RATE_LIMIT_RETRIES:
                        raise
                    print(f"Groq Rate-Limit: Retry {attempt + 1}/{self.MAX_RATE_LIMIT_RETRIES} in {delay:.2f}s")
                    time.sleep(delay)
            if response is None:
                return {"content": "Groq Fehler: Keine Antwort nach Rate-Limit-Retries", "tool_calls": None}
            msg = response.choices[0].message
            return {
                "content": msg.content or "",
                "tool_calls": self._parse_tool_calls_from_response(msg),
            }
        except Exception as e:
            return {"content": f"Groq Fehler: {str(e)}", "tool_calls": None}

    @staticmethod
    def _parse_tool_calls_from_response(msg) -> Optional[List[Dict[str, Any]]]:
        """Parse tool_calls from OpenAI API response message."""
        if not hasattr(msg, "tool_calls") or not msg.tool_calls:
            return None
        return [
            {
                "id": tc.id,
                "function": {"name": tc.function.name, "arguments": tc.function.arguments},
            }
            for tc in msg.tool_calls
        ]

    def is_available(self) -> bool:
        return self._is_initialized

    def get_model_info(self) -> dict:
        return {
            "name": self.model,
            "provider": "groq",
            "local": False,
            "api_configured": bool(self.api_key)
        }

    def list_models(self) -> list[str]:
        if not self._is_initialized:
            return []

        try:
            models = self.client.models.list()
            return [m.id for m in models.data]
        except Exception:
            return list(GROQ_MODELS.keys())


# === Verfügbare Groq Modelle ===
GROQ_MODELS = {
    "openai/gpt-oss-20b": "GPT-OSS 20B - Schnell & günstig (Ersatz für Llama 3.1 8B)",
    "openai/gpt-oss-120b": "GPT-OSS 120B - Hochwertige Formatierung & Reasoning",
    "qwen/qwen3-32b": "Qwen3 32B - Gutes Reasoning",
    "meta-llama/llama-4-scout-17b-16e-instruct": "Llama 4 Scout 17B - Vision & Text",
    "groq/llama-3-8b-8192": "Llama 3 8B - Standard (Fallback)",
}


# === Test-Funktion ===
if __name__ == "__main__":
    from rich.console import Console
    from rich.panel import Panel

    console = Console()
    console.print(Panel("Groq Brain Test", style="bold blue"))

    brain = GroqBrain()

    console.print(f"\n[cyan]1. Prüfe Verfügbarkeit...[/cyan]")
    if brain.is_available():
        console.print("   Groq API ist erreichbar!")

        models = brain.list_models()
        console.print(f"   Verfügbare Modelle: {len(models)}")
        for model in models[:5]:
            console.print(f"      - {model}")

        console.print(f"\n[cyan]2. Test-Generierung (Streaming)...[/cyan]")

        messages = [
            Message(role="system", content="Du bist ein hilfreicher Assistent. Antworte kurz auf Deutsch."),
            Message(role="user", content="Was ist 2+2? Antworte in einem Satz.")
        ]

        console.print("   Antwort: ", end="")
        for token in brain.generate(messages):
            console.print(token, end="")
        console.print()

        console.print("\n[green]Groq Brain Test erfolgreich![/green]")
    else:
        console.print("   Groq ist nicht erreichbar!")
        if not brain.api_key:
            console.print("   Trage deinen API-Key in CHAPPIE_CONFIG.json ein")
        else:
            console.print("   Prüfe deine Internetverbindung oder den API-Key")
