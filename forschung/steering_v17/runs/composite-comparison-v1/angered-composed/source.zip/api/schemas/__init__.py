from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, StrictBool


class SessionRuntimeSettingsPatch(BaseModel):
    model_config = {"extra": "forbid"}
    memory_enabled: Optional[StrictBool] = None
    steering_enabled: Optional[StrictBool] = None
    steering_mode: Optional[Literal["off", "activation", "sequence", "combined"]] = None
    live_enabled: Optional[StrictBool] = None


class HealthResponse(BaseModel):
    ok: bool
    brain_available: bool
    model: str
    provider: str


class StatusResponse(BaseModel):
    brain_available: bool
    model: str
    provider: str = ""
    emotions: Dict[str, int]
    daily_info_count: int
    two_step_enabled: bool
    life_snapshot: Dict[str, Any]
    life_state: Dict[str, Any]


class ChatRequest(BaseModel):
    session_id: Optional[str] = None
    message: str = Field(min_length=1)
    debug_mode: bool = False
    command_mode: bool = False
    client_context: Dict[str, Any] = Field(default_factory=dict)


class ChatResponse(BaseModel):
    session_id: str
    message_id: str
    user_message: Dict[str, Any]
    assistant_message: Dict[str, Any]
    metadata: Dict[str, Any]
    life_snapshot: Dict[str, Any]
    emotion_snapshot: Dict[str, int]
    debug_entries: List[Dict[str, Any]]
    sleep_status: Dict[str, Any]
    retry_history: List[Dict[str, Any]]


class CommandRequest(BaseModel):
    command: str = Field(min_length=1)
    session_id: Optional[str] = None


class CommandResponse(BaseModel):
    session_id: Optional[str] = None
    output: str
    session: Optional[Dict[str, Any]] = None


class SessionCreateRequest(BaseModel):
    title: Optional[str] = None


class SessionUpdateRequest(BaseModel):
    title: Optional[str] = None
    messages: Optional[List[Dict[str, Any]]] = None


class MemoryRecord(BaseModel):
    id: str
    content: str
    role: str
    timestamp: str
    mem_type: str
    relevance_score: float
    label: str


class EmotionLayerUpdate(BaseModel):
    emotion_name: str
    layer_start: int
    layer_end: int
    default_alpha: float


class EmotionStateUpdate(BaseModel):
    happiness: Optional[int] = None
    trust: Optional[int] = None
    energy: Optional[int] = None
    curiosity: Optional[int] = None
    frustration: Optional[int] = None
    motivation: Optional[int] = None
    sadness: Optional[int] = None
    affection: Optional[int] = None
    anxiety: Optional[int] = None
    calm: Optional[int] = None


class TrainingActionRequest(BaseModel):
    action: Literal["start", "stop", "restart", "logs", "clear_logs"]
    focus: Optional[str] = None
    new: bool = False
    lines: int = 200
    config_overrides: Dict[str, Any] = Field(default_factory=dict)


class TrainingActionResponse(BaseModel):
    success: bool
    message: str
    snapshot: Dict[str, Any]
    logs: Optional[str] = None


class SettingsSnapshot(BaseModel):
    llm_provider: str
    ollama_host: str
    ollama_model: str
    vllm_url: str
    vllm_model: str
    gemma4_model: str
    gemma4_steering_model: str
    vllm_force_single_model: bool
    groq_model: str
    groq_format_model: str
    groq_memory_model: str
    groq_auxiliary_enabled: bool
    groq_format_timeout_seconds: float
    intent_provider: Optional[str]
    intent_processor_model_groq: str
    intent_processor_model_ollama: str
    intent_processor_model_vllm: str
    query_extraction_provider: Optional[str]
    query_extraction_ollama_model: str
    query_extraction_vllm_model: str
    query_extraction_groq_model: str
    query_extraction_min_words_for_llm: int
    emotion_analysis_model: str
    emotion_analysis_host: str
    emotion_analysis_provider: Optional[str]
    emotion_analysis_timeout_seconds: float
    embedding_model: str
    training_use_global_settings: bool
    training_chappie_provider: Optional[str]
    training_chappie_model: str
    training_trainer_provider: Optional[str]
    training_trainer_model: str
    memory_top_k: int
    memory_min_relevance: float
    memory_consolidation_enabled: bool
    memory_consolidation_max_tokens: int
    enable_steering: bool
    steering_provider: Optional[str]
    steering_model: str
    steering_vector_pack: str = ""
    steering_quantize: bool
    steering_context_length: int
    use_model_defaults: bool
    temperature: float
    top_p: float
    top_k: int
    repetition_penalty: float
    max_tokens: int
    chappie_thinking_token_limit: int
    chappie_answer_token_limit: int
    history_max_messages: int
    context_token_limit: int
    context_token_warning_threshold: int
    chain_of_thought: bool
    enable_two_step_processing: bool
    stm_summary_threshold: int
    stm_summary_batch_size: int
    groq_requests_per_minute: int
    groq_requests_per_hour: int
    groq_requests_per_day: int
    groq_tokens_per_minute: int
    groq_tokens_per_hour: int
    groq_tokens_per_day: int


class SettingsUpdate(BaseModel):
    llm_provider: Optional[str] = None
    groq_api_key: Optional[str] = None
    groq_model: Optional[str] = None
    groq_format_model: Optional[str] = None
    groq_memory_model: Optional[str] = None
    groq_auxiliary_enabled: Optional[bool] = None
    groq_format_timeout_seconds: Optional[float] = None
    vllm_model: Optional[str] = None
    gemma4_model: Optional[str] = None
    gemma4_steering_model: Optional[str] = None
    vllm_url: Optional[str] = None
    vllm_force_single_model: Optional[bool] = None
    ollama_model: Optional[str] = None
    ollama_host: Optional[str] = None
    intent_provider: Optional[str] = None
    intent_processor_model_groq: Optional[str] = None
    intent_processor_model_ollama: Optional[str] = None
    intent_processor_model_vllm: Optional[str] = None
    query_extraction_provider: Optional[str] = None
    query_extraction_ollama_model: Optional[str] = None
    query_extraction_vllm_model: Optional[str] = None
    query_extraction_groq_model: Optional[str] = None
    query_extraction_min_words_for_llm: Optional[int] = None
    emotion_analysis_model: Optional[str] = None
    emotion_analysis_host: Optional[str] = None
    emotion_analysis_provider: Optional[str] = None
    emotion_analysis_timeout_seconds: Optional[float] = None
    embedding_model: Optional[str] = None
    training_use_global_settings: Optional[bool] = None
    training_chappie_provider: Optional[str] = None
    training_chappie_model: Optional[str] = None
    training_trainer_provider: Optional[str] = None
    training_trainer_model: Optional[str] = None
    memory_top_k: Optional[int] = None
    memory_min_relevance: Optional[float] = None
    memory_consolidation_enabled: Optional[bool] = None
    memory_consolidation_max_tokens: Optional[int] = None
    enable_steering: Optional[bool] = None
    steering_provider: Optional[str] = None
    steering_model: Optional[str] = None
    steering_vector_pack: Optional[str] = None
    steering_quantize: Optional[bool] = None
    steering_context_length: Optional[int] = None
    use_model_defaults: Optional[bool] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    repetition_penalty: Optional[float] = None
    max_tokens: Optional[int] = None
    chappie_thinking_token_limit: Optional[int] = None
    chappie_answer_token_limit: Optional[int] = None
    history_max_messages: Optional[int] = None
    context_token_limit: Optional[int] = None
    context_token_warning_threshold: Optional[int] = None
    chain_of_thought: Optional[bool] = None
    enable_two_step_processing: Optional[bool] = None
    stm_summary_threshold: Optional[int] = None
    stm_summary_batch_size: Optional[int] = None
    groq_requests_per_minute: Optional[int] = None
    groq_requests_per_hour: Optional[int] = None
    groq_requests_per_day: Optional[int] = None
    groq_tokens_per_minute: Optional[int] = None
    groq_tokens_per_hour: Optional[int] = None
    groq_tokens_per_day: Optional[int] = None


class ContextFileUpdate(BaseModel):
    content: str = Field(min_length=0)
    groq_api_key: Optional[str] = None
    groq_model: Optional[str] = None
    groq_format_model: Optional[str] = None
    groq_memory_model: Optional[str] = None
    vllm_model: Optional[str] = None
    vllm_url: Optional[str] = None
    vllm_force_single_model: Optional[bool] = None
    ollama_model: Optional[str] = None
    ollama_host: Optional[str] = None
    intent_provider: Optional[str] = None
    intent_processor_model_groq: Optional[str] = None
    intent_processor_model_ollama: Optional[str] = None
    intent_processor_model_vllm: Optional[str] = None
    query_extraction_provider: Optional[str] = None
    query_extraction_ollama_model: Optional[str] = None
    query_extraction_vllm_model: Optional[str] = None
    query_extraction_groq_model: Optional[str] = None
    query_extraction_min_words_for_llm: Optional[int] = None
    emotion_analysis_model: Optional[str] = None
    emotion_analysis_host: Optional[str] = None
    embedding_model: Optional[str] = None
    training_use_global_settings: Optional[bool] = None
    training_chappie_provider: Optional[str] = None
    training_chappie_model: Optional[str] = None
    training_trainer_provider: Optional[str] = None
    training_trainer_model: Optional[str] = None
    memory_top_k: Optional[int] = None
    memory_min_relevance: Optional[float] = None
    memory_consolidation_enabled: Optional[bool] = None
    memory_consolidation_max_tokens: Optional[int] = None
    enable_steering: Optional[bool] = None
    steering_provider: Optional[str] = None
    steering_model: Optional[str] = None
    steering_vector_pack: Optional[str] = None
    steering_quantize: Optional[bool] = None
    steering_context_length: Optional[int] = None
    temperature: Optional[float] = None
    repetition_penalty: Optional[float] = None
    max_tokens: Optional[int] = None
    chappie_thinking_token_limit: Optional[int] = None
    chappie_answer_token_limit: Optional[int] = None
    history_max_messages: Optional[int] = None
    context_token_limit: Optional[int] = None
    context_token_warning_threshold: Optional[int] = None
    chain_of_thought: Optional[bool] = None
    enable_two_step_processing: Optional[bool] = None
    stm_summary_threshold: Optional[int] = None
    stm_summary_batch_size: Optional[int] = None
    groq_requests_per_minute: Optional[int] = None
    groq_requests_per_hour: Optional[int] = None
    groq_requests_per_day: Optional[int] = None
    groq_tokens_per_minute: Optional[int] = None
    groq_tokens_per_hour: Optional[int] = None
    groq_tokens_per_day: Optional[int] = None
